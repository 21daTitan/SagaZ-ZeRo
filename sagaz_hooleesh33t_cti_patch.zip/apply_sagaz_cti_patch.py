#!/usr/bin/env python3
"""Apply the read-only ALFA CTI integration to an existing SagaZ-ZeRo repository."""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
FILES = (
    'sagaz/cti/__init__.py',
    'knowledge/cti/lote2.json',
    '.agents/skills/cti-intelligence/SKILL.md',
    'tests/test_cti.py',
    'docs/ALFA-CTI-INTEGRATION.md',
)


def once(text: str, old: str, new: str, name: str) -> str:
    if new in text:
        return text
    if text.count(old) != 1:
        raise RuntimeError(f'{name}: expected anchor exactly once; found {text.count(old)}')
    return text.replace(old, new, 1)


def edits(target: Path) -> dict[Path, str]:
    updated = {}
    def read(p):
        return (target/p).read_text(encoding='utf-8')

    name = 'sagaz/gateway/policy.py'
    source = read(name)
    original = 'frozenset({"sagaz_status", "sagaz_skills"})'
    replacement = 'frozenset({"sagaz_status", "sagaz_skills", "sagaz_cti_search", "sagaz_cti_summary"})'
    if source.count(original) == 2:
        source = source.replace(original, replacement)
    elif source.count(replacement) != 2:
        raise RuntimeError(f'{name}: unexpected tool scope declarations')
    updated[target/name] = source

    name='sagaz/tools/builtin.py'; source = read(name)
    source = once(source, 'from sagaz.catalog import skills',
                  'from sagaz.catalog import skills\nfrom sagaz.cti import summary as cti_summary, search as cti_search', name)
    source = once(source, "    'sagaz_skills': skills,", "    'sagaz_skills': skills,\n    'sagaz_cti_summary': cti_summary,\n    'sagaz_cti_search': cti_search,", name)
    updated[target/name] = source

    name='sagaz/tools/bus.py'; source = read(name)
    source = once(source, "        if arguments not in ({}, None):\n            raise ValueError('No arguments accepted for this tool')\n        result = BUILTINS[name]()",
    "        if name == 'sagaz_cti_search':\n            if not isinstance(arguments, dict) or set(arguments) - {'query', 'limit'}:\n                raise ValueError('Invalid CTI search arguments')\n            result = BUILTINS[name](arguments.get('query'), arguments.get('limit', 10))\n        else:\n            if arguments not in ({}, None):\n                raise ValueError('No arguments accepted for this tool')\n            result = BUILTINS[name]()", name)
    updated[target/name] = source

    name='sagaz/gateway/mcp.py'; source = read(name)
    anchor = '''    {"name": "sagaz_skills", "description": "List installed skill manifests",
     "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False}},'''
    source=once(source, anchor, anchor + '''
    {"name": "sagaz_cti_summary", "description": "Summarize unverified ALFA CTI records",
     "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False}},
    {"name": "sagaz_cti_search", "description": "Read-only CTI search; returned claims are unverified",
     "inputSchema": {"type": "object", "properties": {
         "query": {"type": "string", "minLength": 1, "maxLength": 120},
         "limit": {"type": "integer", "minimum": 1, "maximum": 20}},
         "required": ["query"], "additionalProperties": False}},''', name)
    updated[target/name]=source

    name='sagaz/app.py'; source=read(name)
    source=once(source, 'from urllib.parse import urlparse', 'from urllib.parse import urlparse, parse_qs',name)
    source=once(source, 'from sagaz.catalog import skills, connection',
                'from sagaz.catalog import skills, connection\nfrom sagaz.cti import search as cti_search, summary as cti_summary',name)
    anchor="        if path=='/api/skills':return self.send(200,skills())"
    source=once(source, anchor, anchor + '''
        if path in ('/api/cti/search', '/api/cti/summary'):
            if self.scope().connector == 'public':
                return self.send(403, {'error': 'Autenticação necessária'})
            try:
                if path == '/api/cti/summary':
                    return self.send(200, cti_summary())
                params = parse_qs(urlparse(self.path).query, keep_blank_values=True)
                if set(params) - {'q', 'limit'} or len(params.get('q', [])) != 1 or len(params.get('limit', [])) > 1:
                    raise ValueError('Invalid CTI query parameters')
                limit = int(params.get('limit', ['10'])[0])
                return self.send(200, cti_search(params['q'][0], limit))
            except (ValueError, TypeError, KeyError) as exc:
                return self.send(400, {'error': str(exc)})''',name)
    updated[target/name]=source

    name='sagaz/static/app.js'; source=read(name)
    source=once(source,"const commands = {'/skills':'skills','/projects':'projects','/research':'research','/connect':'settings','/console':'console'};",
"const commands = {'/skills':'skills','/projects':'projects','/research':'research','/connect':'settings','/console':'console'};",name) if False else source
    source=once(source, "/skills · catálogo de skills\\n/research", "/skills · catálogo de skills\\n/cti <termo> · consulta CTI offline\\n/research",name)
    source=once(source, "  else if (text === '/status') api('/api/status').then(d=>message('assistant',JSON.stringify(d,null,2))).catch(e=>message('assistant',e.message));",
"  else if (text.startsWith('/cti ')) {\n    const q = text.slice(5).trim();\n    api('/api/cti/search?q='+encodeURIComponent(q)).then(d=>message('assistant',JSON.stringify(d,null,2))).catch(e=>message('assistant',e.message));\n  }\n  else if (text === '/cti') api('/api/cti/summary').then(d=>message('assistant',JSON.stringify(d,null,2))).catch(e=>message('assistant',e.message));\n  else if (text === '/status') api('/api/status').then(d=>message('assistant',JSON.stringify(d,null,2))).catch(e=>message('assistant',e.message));",name)
    updated[target/name]=source

    name='tests/test_sagaz.py'; source=read(name)
    source=once(source,"self.assertEqual(data['count'],6)","self.assertEqual(data['count'],7)",name)
    updated[target/name]=source
    return updated


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--repo',default='.',help='Existing SagaZ-ZeRo checkout')
    parser.add_argument('--dry-run',action='store_true')
    args=parser.parse_args()
    root=Path(args.repo).resolve()
    for path in ('sagaz/app.py','sagaz/gateway/mcp.py','sagaz/static/app.js','.agents/skills/dsant-creator/SKILL.md'):
        if not (root/path).is_file():
            parser.error(f'Not a supported SagaZ checkout: missing {path}')
    changes=edits(root)
    for p in FILES:
        dest=root/p
        if dest.exists() and dest.read_bytes() != (HERE/p).read_bytes():
            parser.error(f'Refusing overwrite of different file: {p}')
    for dest,text in changes.items():
        if args.dry_run:
            print('MODIFY',dest.relative_to(root))
        else:
            dest.write_text(text,encoding='utf-8')
    for rel in FILES:
        if args.dry_run:
            print('ADD',rel)
        else:
            destination=root/rel
            destination.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(HERE/rel,destination)
    if not args.dry_run:
        print('PATCH_APPLIED: run python -m unittest discover -s tests -v and python dsant.py doctor')

if __name__=='__main__':main()
